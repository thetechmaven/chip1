/* Project related typedefs */

const projectTypedefs = `
    type Query {
      sampleQuery: String
    }
    type Mutation {
        sampleMutation: String
    }
`;

export default projectTypedefs;
