// Project Queries here
export default {};
