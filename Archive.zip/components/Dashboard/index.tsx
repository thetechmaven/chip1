import React from 'react';
import Users from './Users';

function Dashboard() {
  return <Users />;
}

export default Dashboard;
