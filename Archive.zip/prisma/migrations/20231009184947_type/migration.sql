-- AlterTable
ALTER TABLE "User" ADD COLUMN     "typePreference" TEXT[];
