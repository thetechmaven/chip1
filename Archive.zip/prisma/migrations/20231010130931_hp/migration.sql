-- AlterTable
ALTER TABLE "User" ADD COLUMN     "hp" TEXT;
