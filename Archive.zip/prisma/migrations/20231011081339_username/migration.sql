-- AlterTable
ALTER TABLE "User" ADD COLUMN     "username" TEXT;
