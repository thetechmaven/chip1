-- AlterTable
ALTER TABLE "User" ADD COLUMN     "group" TEXT;
