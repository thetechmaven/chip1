-- DropIndex
DROP INDEX "User_email_key";
