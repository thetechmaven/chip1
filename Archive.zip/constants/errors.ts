export const URL_EXPIRED_OR_INVALID = 'The Url has expired or is invalid';
