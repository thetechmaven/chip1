export const RESET_PASSWORD = 'Reset your password';
export const SUBJECT_VERIFY_EMAIL = 'Verify your email address';
