import Login from '@/components/Auth/Login';

export default Login;
