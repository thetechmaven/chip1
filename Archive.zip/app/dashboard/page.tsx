import Dashboard from '@/components/Dashboard';

export default Dashboard;
