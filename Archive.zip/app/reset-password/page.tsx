import ResetPassword from '@/components/ResetPassword';
import React from 'react';

const Page = () => {
  return <ResetPassword />;
};

export default Page;
