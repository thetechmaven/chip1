export * from './messages';

export const USER_TYPE = 'USER_TYPE';
export const USER_TYPE_CREATOR = 'CREATOR';
export const USER_TYPE_BRAND = 'BRAND';
export const UPDATE_PROFILE = 'UPDATE_PROFILE';
